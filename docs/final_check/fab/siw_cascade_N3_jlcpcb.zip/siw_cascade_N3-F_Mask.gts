G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,9.0.9-9.0.9~ubuntu24.04.1*
G04 #@! TF.CreationDate,2026-09-23T04:10:03+00:00*
G04 #@! TF.ProjectId,siw_cascade_N3,7369775f-6361-4736-9361-64655f4e332e,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 9.0.9-9.0.9~ubuntu24.04.1) date 2026-09-23 04:10:03*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
%ADD10C,0.000000*%
G04 APERTURE END LIST*
D10*
G36*
X134581300Y-22895000D02*
G01*
X-31200300Y-22895000D01*
X-31200300Y22895000D01*
X134581300Y22895000D01*
X134581300Y-22895000D01*
G37*
M02*
